class ElementNotInDom(Exception):
    pass


class PropsError(ValueError):
    pass
